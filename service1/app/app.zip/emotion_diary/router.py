from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from .vo import EmotionDiaryRequestVO, EmotionDiaryResponseVO, EmotionDiaryErrorVO
from .service import EmotionDiaryService
from ..database import get_db

router = APIRouter()

def get_service(db: Session = Depends(get_db)) -> EmotionDiaryService:
    return EmotionDiaryService(db)

@router.post("/diaryChat", response_model=EmotionDiaryResponseVO)
def get_emotion_response(
    vo: EmotionDiaryRequestVO, 
    service: EmotionDiaryService = Depends(get_service)
):
    """감정일기에 대한 AI 응답을 받는 엔드포인트"""
    response = service.get_ai_response(vo)
    
    # 에러 응답인 경우 HTTPException 발생
    if isinstance(response, EmotionDiaryErrorVO):
        raise HTTPException(
            status_code=response.status_code, 
            detail=response.error
        )
    
    return response