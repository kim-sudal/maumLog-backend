from pydantic import BaseModel
from typing import Optional

class EmotionDiaryRequestVO(BaseModel):
    content: str
    max_tokens: int = 1000
    temperature: float = 0.7

class EmotionDiaryResponseVO(BaseModel):
    ai_response: str
    model: str
    success: bool = True
    
class EmotionDiaryErrorVO(BaseModel):
    error: str
    status_code: int
    success: bool = False