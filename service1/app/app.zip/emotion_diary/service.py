from typing import Union
from ..common.common_vo import ChatGPTRequestVO
from ..common.common_service import ChatGPTService
from ..common.common_repository import ChatGPTRepository
from .vo import EmotionDiaryRequestVO, EmotionDiaryResponseVO, EmotionDiaryErrorVO

class EmotionDiaryService:
    def __init__(self, db):
        self.db = db
        # 공통 ChatGPT 서비스 사용
        self.chat_repo = ChatGPTRepository(db)
        self.chat_service = ChatGPTService(self.chat_repo)
    
    def get_ai_response(self, vo: EmotionDiaryRequestVO) -> Union[EmotionDiaryResponseVO, EmotionDiaryErrorVO]:
        """감정일기에 대한 AI 응답을 받는 서비스 함수"""
        
        # 공통 ChatGPT 요청 VO로 변환
        chat_request = ChatGPTRequestVO(
            prompt=vo.content,
            max_tokens=vo.max_tokens,
            temperature=vo.temperature
        )
        
        # 공통 서비스를 통해 ChatGPT 호출
        chat_response = self.chat_service.get_chat_response(chat_request)
        
        # 에러 응답 처리
        if hasattr(chat_response, 'error'):
            return EmotionDiaryErrorVO(
                error=chat_response.error,
                status_code=chat_response.status_code
            )
        
        # 성공 응답을 감정일기용 응답으로 변환
        return EmotionDiaryResponseVO(
            ai_response=chat_response.content,
            model=chat_response.model
        )